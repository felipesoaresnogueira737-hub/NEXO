# NEXO — robô de IA por voz para Android

Kotlin + Jetpack Compose + Gemini (REST oficial) + SpeechRecognizer + TextToSpeech.

## Chave do Gemini (duas opções)
1. **Pelo GitHub (embutida no APK):** repositório → Settings → Secrets and variables → Actions → *New repository secret* → nome `GEMINI_API_KEY`.
   ⚠ Use repositório **privado**: a chave fica dentro do APK e, em repo público, qualquer pessoa logada no GitHub baixa o artifact.
2. **Dentro do app (mais seguro):** deixe o secret vazio. Ao abrir o NEXO ele pede a chave; depois, **segure o dedo na tela** para abrir as configurações. Fica só no armazenamento privado do app.
Modelo opcional: *Settings → Variables* → `GEMINI_MODEL` (padrão `gemini-flash-latest`).

## Compilar
Suba o conteúdo desta pasta na raiz de um repositório → aba **Actions** → *Build NEXO APK* → **Run workflow** (também roda a cada push).
APK: na execução concluída, seção **Artifacts** → `NEXO-apk` (contém `release` e `debug`; instale o release).

## Uso
Abre escutando. Fale e ele responde. Toque: interrompe a fala / pausa a escuta / acorda. Segurar: configurações (chave, apagar memória).
