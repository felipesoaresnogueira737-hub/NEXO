package com.nexo.app.face

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Estado vivo do rosto: emoção, piscadas, olhar, respiração e microexpressões. */
class FaceController {
    var clock = 0f; private set
    private var stateSince = 0f
    private var idleSince = 0f

    var state: VoiceState = VoiceState.IDLE
        set(v) {
            if (field != v) {
                field = v
                stateSince = clock
                if (v == VoiceState.IDLE) idleSince = clock
            }
        }

    // emoção vinda do Gemini
    private var emotion = Emotion.NEUTRAL
    private var intensity = 0f
    private var emotionStamp = 0f
    private var behavior = "none"
    private var behaviorUntil = 0f
    private var hintX = 0f
    private var hintY = 0f
    private var hintUntil = 0f

    // entradas de áudio
    var rmsIn = 0f
    var rms = 0f; private set
    var pulse = 0f; private set
    fun wordPulse() { pulse = 1f }

    private val cur = FloatArray(FaceParams.SIZE).also { FaceParams().toArray().copyInto(it) }

    var blinkL = 1f; private set
    var blinkR = 1f; private set
    var gazeX = 0f; private set
    var gazeY = 0f; private set
    var breath = 0f; private set

    private var nextBlink = 1.5f
    private var blinkStart = -1f
    private var doubleDone = false
    private var winkStart = -10f
    private var nextGaze = 0f
    private var gtx = 0f
    private var gty = 0f
    private var nextMicro = 9f
    private var micro: Emotion? = null
    private var microUntil = 0f
    private var microInt = 0f

    fun params(): FaceParams = FaceParams.fromArray(cur)

    fun setExpression(e: Emotion, i: Float, gaze: String, beh: String) {
        emotion = e
        intensity = i.coerceIn(0f, 1f)
        emotionStamp = clock
        val hint: Pair<Float, Float>? = when (gaze) {
            "up" -> 0f to -0.8f
            "down" -> 0f to 0.7f
            "left" -> -0.9f to 0f
            "right" -> 0.9f to 0f
            "up_left" -> -0.8f to -0.7f
            "up_right" -> 0.8f to -0.7f
            "away" -> (if (Random.nextBoolean()) -0.9f else 0.9f) to -0.2f
            else -> null
        }
        if (hint != null) { hintX = hint.first; hintY = hint.second; hintUntil = clock + 2.5f } else hintUntil = 0f
        behavior = beh
        behaviorUntil = clock + when (beh) { "wink" -> 0.6f; "look_around" -> 2.2f; "giggle" -> 1.6f; else -> 1.8f }
        if (beh == "wink") winkStart = clock
    }

    fun resetExpression() { emotion = Emotion.NEUTRAL; intensity = 0f }

    fun update(dt: Float, now: Float) {
        clock = now
        rms += (rmsIn - rms) * (1f - exp(-dt * 14f))
        pulse = max(0f, pulse - dt * 4.5f)

        var e = emotion
        var inten = intensity
        if (state == VoiceState.SPEAKING) emotionStamp = now
        inten *= 1f - ((now - emotionStamp - 8f) / 12f).coerceIn(0f, 1f)

        val awakeIdle = state == VoiceState.IDLE && now - idleSince < 40f
        when (state) {
            VoiceState.THINKING -> { e = Emotion.THINKING; inten = 0.85f }
            VoiceState.IDLE -> if (!awakeIdle) { e = Emotion.SLEEPY; inten = 0.9f }
            else -> {}
        }

        // microexpressões espontâneas
        if ((awakeIdle || state == VoiceState.LISTENING) && now >= nextMicro) {
            val opts = listOf(Emotion.CURIOUS to 0.45f, Emotion.HAPPY to 0.35f, Emotion.THINKING to 0.4f, Emotion.CONFUSED to 0.3f)
            val o = opts.random()
            micro = o.first; microInt = o.second; microUntil = now + 1.8f
            nextMicro = now + 7f + Random.nextFloat() * 8f
        }
        micro?.let { if (now < microUntil) { e = it; inten = microInt } else micro = null }

        var p = FaceParams().lerp(presetFor(e), inten.coerceIn(0f, 1f))

        if (now < behaviorUntil) {
            p = when (behavior) {
                "squint" -> p.copy(eyeH = p.eyeH * 0.6f, drop = p.drop + 0.1f)
                "wide_eyes" -> p.copy(eyeH = p.eyeH * 1.25f, eyeW = p.eyeW * 1.08f)
                "giggle" -> p.copy(happyCut = max(p.happyCut, 0.6f), smile = max(p.smile, 0.8f), eyeY = p.eyeY + sin(now * 26f) * 0.12f)
                else -> p
            }
        }
        if (e == Emotion.EXCITED) p = p.copy(eyeY = p.eyeY + sin(now * 10f) * 0.03f * inten)
        if (state == VoiceState.LISTENING) p = p.copy(eyeH = p.eyeH * 1.06f, eyeW = p.eyeW * 1.03f)
        if (state == VoiceState.SPEAKING) {
            val dyn = (0.12f + 0.55f * pulse + 0.2f * abs(sin(now * 9f))).coerceAtMost(1f)
            p = p.copy(open = max(p.open * 0.6f, dyn))
        }

        val t = p.toArray()
        for (i in cur.indices) {
            val sp = when (i) { FaceParams.I_OPEN -> 24f; 0, 1 -> 12f; else -> 9f }
            cur[i] += (t[i] - cur[i]) * (1f - exp(-dt * sp))
        }

        // piscadas
        var bf = 1f
        if (blinkStart < 0f && now >= nextBlink) blinkStart = now
        if (blinkStart >= 0f) {
            val pr = (now - blinkStart) / 0.16f
            if (pr >= 1f) {
                blinkStart = -1f
                if (!doubleDone && Random.nextFloat() < 0.15f) { doubleDone = true; nextBlink = now + 0.12f }
                else { doubleDone = false; nextBlink = now + 2.2f + Random.nextFloat() * 3.5f }
            } else bf = 1f - 0.95f * sin(PI.toFloat() * pr)
        }
        blinkL = bf
        val wp = (now - winkStart) / 0.45f
        blinkR = if (wp in 0f..1f) min(bf, 1f - 0.94f * sin(PI.toFloat() * wp)) else bf

        // olhar
        if (now >= nextGaze) {
            if (now < behaviorUntil && behavior == "look_around") {
                gtx = Random.nextFloat() * 2f - 1f; gty = Random.nextFloat() * 1.2f - 0.6f; nextGaze = now + 0.35f
            } else when (state) {
                VoiceState.IDLE -> { gtx = rnd(-0.9f, 0.9f); gty = rnd(-0.5f, 0.5f); nextGaze = now + rnd(1.2f, 3.5f) }
                VoiceState.LISTENING -> { gtx = rnd(-0.25f, 0.25f); gty = rnd(-0.2f, 0.1f); nextGaze = now + rnd(1.5f, 3f) }
                VoiceState.THINKING -> { gtx = if (Random.nextBoolean()) 0.6f else -0.6f; gty = -0.7f + rnd(-0.1f, 0.1f); nextGaze = now + rnd(0.8f, 1.6f) }
                VoiceState.SPEAKING -> { gtx = rnd(-0.4f, 0.4f); gty = rnd(-0.25f, 0.25f); nextGaze = now + rnd(1f, 2.5f) }
            }
        }
        val tx = (if (now < hintUntil) hintX else gtx + cur[FaceParams.I_LOOK_X]).coerceIn(-1f, 1f)
        val ty = (if (now < hintUntil) hintY else gty + cur[FaceParams.I_LOOK_Y]).coerceIn(-1f, 1f)
        val gs = 1f - exp(-dt * 10f)
        gazeX += (tx - gazeX) * gs
        gazeY += (ty - gazeY) * gs

        breath = sin(now * 1.7f)
    }

    private fun rnd(a: Float, b: Float) = a + Random.nextFloat() * (b - a)
}
