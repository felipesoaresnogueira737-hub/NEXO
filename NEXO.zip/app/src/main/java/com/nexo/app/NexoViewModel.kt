package com.nexo.app

import android.app.Application
import android.content.Context
import android.speech.SpeechRecognizer
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexo.app.ai.GeminiClient
import com.nexo.app.ai.GeminiException
import com.nexo.app.ai.GeminiReply
import com.nexo.app.ai.Persona
import com.nexo.app.face.Emotion
import com.nexo.app.face.FaceController
import com.nexo.app.face.VoiceState
import com.nexo.app.memory.MemoryStore
import com.nexo.app.memory.Turn
import com.nexo.app.voice.SpeechInput
import com.nexo.app.voice.SpeechOutput
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val voice: VoiceState = VoiceState.IDLE,
    val notice: String? = null,
    val showSettings: Boolean = false,
    val hasKey: Boolean = false
)

class NexoViewModel(app: Application) : AndroidViewModel(app), SpeechInput.Listener, SpeechOutput.Callback {
    val face = FaceController()

    private val prefs = app.getSharedPreferences("nexo", Context.MODE_PRIVATE)
    private val memory = MemoryStore(app)
    private val gemini = GeminiClient(
        keyProvider = { currentKey() },
        preferredModel = { prefs.getString("model_ok", null)?.takeIf { it.isNotBlank() } ?: BuildConfig.GEMINI_MODEL },
        onModelWorked = { prefs.edit().putString("model_ok", it).apply() }
    )
    private val speechIn = SpeechInput(app, this)
    private val speechOut = SpeechOutput(app, this)

    private val _ui = MutableStateFlow(UiState(hasKey = currentKey().isNotBlank()))
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private var micGranted = false
    private var active = false
    private var job: Job? = null
    private var restartJob: Job? = null
    private var silences = 0
    private var errors = 0
    private var stopAfterSpeech = false

    private fun currentKey(): String =
        (prefs.getString("gemini_key", null)?.takeIf { it.isNotBlank() } ?: BuildConfig.GEMINI_API_KEY).trim()

    private fun setVoice(v: VoiceState) {
        face.state = v
        if (v != VoiceState.LISTENING) face.rmsIn = 0f
        _ui.update { it.copy(voice = v) }
    }

    private fun notice(msg: String?) = _ui.update { it.copy(notice = msg) }

    // ---------- ciclo de vida / entrada do usuário ----------

    fun onMicPermission(granted: Boolean) {
        micGranted = granted
        if (granted) onForeground() else {
            notice("Preciso da permissão do microfone. Toque na tela para tentar de novo.")
            face.setExpression(Emotion.SAD, 0.6f, "down", "none")
        }
    }

    fun onForeground() {
        if (!micGranted || _ui.value.showSettings || _ui.value.voice != VoiceState.IDLE) return
        if (currentKey().isBlank()) { openSettings(); return }
        active = true; silences = 0; errors = 0
        viewModelScope.launch {
            if (memory.isEmpty()) respond("(O usuário acabou de abrir o app pela primeira vez. Se apresente de um jeito curto, divertido e curioso, e pergunte o nome dele.)")
            else startListening()
        }
    }

    fun onBackground() {
        active = false
        job?.cancel(); restartJob?.cancel()
        speechIn.stop(); speechOut.stop()
        setVoice(VoiceState.IDLE)
    }

    /** Toque: fala -> interrompe e escuta; escuta -> pausa; pensando -> cancela e escuta; ocioso -> acorda. */
    fun onTap() {
        if (_ui.value.showSettings) return
        when (_ui.value.voice) {
            VoiceState.SPEAKING, VoiceState.THINKING -> { active = true; silences = 0; startListening() }
            VoiceState.LISTENING -> goIdle()
            VoiceState.IDLE -> {
                if (!micGranted) { notice("Permita o microfone nas configurações do app"); return }
                if (currentKey().isBlank()) { openSettings(); return }
                active = true; silences = 0; errors = 0; startListening()
            }
        }
    }

    private fun goIdle() {
        active = false
        job?.cancel(); restartJob?.cancel()
        speechIn.stop(); speechOut.stop()
        setVoice(VoiceState.IDLE)
    }

    private fun startListening() {
        job?.cancel(); restartJob?.cancel(); speechOut.stop()
        if (!speechIn.isAvailable()) {
            notice("Reconhecimento de voz indisponível neste aparelho")
            goIdle(); return
        }
        notice(null)
        setVoice(VoiceState.LISTENING)
        speechIn.start()
    }

    private fun restartListening(ms: Long) {
        restartJob?.cancel()
        restartJob = viewModelScope.launch {
            delay(ms)
            if (active && face.state == VoiceState.LISTENING) startListening()
        }
    }

    // ---------- SpeechInput.Listener ----------

    override fun onRms(level: Float) { face.rmsIn = level }
    override fun onSpeechStart() { face.setExpression(Emotion.CURIOUS, 0.3f, "center", "none") }

    override fun onResult(text: String) {
        if (text.isBlank()) { onError(SpeechRecognizer.ERROR_NO_MATCH); return }
        silences = 0; errors = 0
        job?.cancel()
        job = viewModelScope.launch { respond(text) }
    }

    override fun onError(code: Int) {
        when (code) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                silences++
                if (silences >= 3) goIdle() else restartListening(300)
            }
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                micGranted = false; notice("Sem permissão de microfone"); goIdle()
            }
            else -> {
                errors++
                if (errors >= 3) { notice("Falha no reconhecimento de voz (código $code). Toque para tentar de novo."); goIdle() }
                else restartListening(if (code == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 900 else 700)
            }
        }
    }

    // ---------- Gemini ----------

    private suspend fun respond(userText: String) {
        setVoice(VoiceState.THINKING)
        try {
            val ctx = memory.contextFor(userText)
            val reply = gemini.chat(Persona.system(ctx.memoryBlock), ctx.recent, userText)
            memory.addExchange(Turn("user", userText), Turn("model", reply.response, emotion = reply.emotion.id))
            memory.applyMemories(reply.memories)
            say(reply.response, reply.emotion, reply.intensity, reply.gaze, reply.behavior)
            viewModelScope.launch {
                try { memory.compactIfNeeded { prev, turns -> gemini.summarize(prev, turns) } } catch (_: Exception) {}
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: GeminiException) {
            handleFailure(e)
        } catch (e: Exception) {
            canned("Deu um nó nos meus circuitos. Tenta de novo?", Emotion.CONFUSED)
            notice(e.message?.take(120))
        }
    }

    private fun handleFailure(e: GeminiException) {
        when (e.kind) {
            GeminiException.Kind.NO_KEY -> { goIdle(); openSettings() }
            GeminiException.Kind.BAD_KEY -> {
                notice("Chave da API inválida ou sem permissão")
                stopAfterSpeech = true
                canned("Minha chave de acesso parece inválida. Segura o dedo na tela pra colocar uma nova.", Emotion.CONFUSED)
            }
            GeminiException.Kind.NETWORK -> canned("Parece que estou sem internet. Tenta de novo daqui a pouco.", Emotion.SAD)
            GeminiException.Kind.RATE -> canned("Estou meio sobrecarregado agora, me dá uns segundinhos.", Emotion.SLEEPY)
            GeminiException.Kind.BLOCKED, GeminiException.Kind.BAD_REPLY ->
                canned("Hmm, não consegui responder isso. Tenta falar de outro jeito?", Emotion.CONFUSED)
            else -> { notice(e.message?.take(140)); canned("Deu um nó nos meus circuitos. Tenta de novo?", Emotion.CONFUSED) }
        }
    }

    private fun canned(text: String, emotion: Emotion) = say(text, emotion, 0.6f, "center", "none")

    private fun say(text: String, emotion: Emotion, intensity: Float, gaze: String, behavior: String) {
        face.setExpression(emotion, intensity, gaze, behavior)
        setVoice(VoiceState.SPEAKING)
        // voz acompanha a emoção
        val k = intensity.coerceIn(0f, 1f)
        val (rate, pitch) = when (emotion) {
            Emotion.EXCITED -> 1.2f to 1.15f
            Emotion.HAPPY -> 1.1f to 1.08f
            Emotion.SAD -> 0.88f to 0.9f
            Emotion.ANGRY -> 1.1f to 0.92f
            Emotion.SLEEPY -> 0.8f to 0.85f
            Emotion.SURPRISED -> 1.15f to 1.15f
            Emotion.CURIOUS -> 1.0f to 1.05f
            Emotion.THINKING -> 0.95f to 1.0f
            Emotion.CONFUSED -> 0.95f to 1.02f
            Emotion.NEUTRAL -> 1.0f to 1.0f
        }
        speechOut.speak(text, 1f + (rate - 1f) * k, 1f + (pitch - 1f) * k)
    }

    // ---------- SpeechOutput.Callback ----------

    override fun onSpeakStart() {}
    override fun onWord() { face.wordPulse() }
    override fun onVoiceProblem(message: String) { notice(message) }

    override fun onSpeakEnd(interrupted: Boolean) {
        if (face.state != VoiceState.SPEAKING) return
        if (stopAfterSpeech) { stopAfterSpeech = false; goIdle(); return }
        if (!active) { setVoice(VoiceState.IDLE); return }
        // pequena pausa para o microfone não captar o final da própria voz
        setVoice(VoiceState.LISTENING)
        restartListening(450)
    }

    // ---------- configurações ----------

    fun openSettings() {
        active = false
        job?.cancel(); restartJob?.cancel(); speechIn.stop(); speechOut.stop()
        setVoice(VoiceState.IDLE)
        _ui.update { it.copy(showSettings = true, hasKey = currentKey().isNotBlank()) }
    }

    fun saveKey(key: String) {
        prefs.edit().putString("gemini_key", key.trim()).remove("model_ok").apply()
        _ui.update { it.copy(hasKey = currentKey().isNotBlank()) }
    }

    fun clearMemory() { viewModelScope.launch { memory.clearAll() } }

    fun closeSettings() {
        _ui.update { it.copy(showSettings = false, hasKey = currentKey().isNotBlank()) }
        onForeground()
    }

    override fun onCleared() {
        speechIn.stop()
        speechOut.shutdown()
        super.onCleared()
    }
}
