package com.nexo.app.memory

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.Normalizer
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

data class Turn(val role: String, val text: String, val ts: Long = System.currentTimeMillis(), val emotion: String? = null)
data class Fact(val type: String, val text: String, val ts: Long = System.currentTimeMillis())
data class PromptContext(val memoryBlock: String, val recent: List<Turn>)

/**
 * Memória local persistente (arquivos JSON em filesDir):
 *  - history.jsonl : histórico completo de todas as conversas (só acrescenta)
 *  - state.json    : resumo + fatos/preferências + janela recente de turnos
 * Só a janela recente, o resumo e fatos relevantes vão para o Gemini.
 */
class MemoryStore(context: Context) {
    private val dir = File(context.filesDir, "nexo").apply { mkdirs() }
    private val stateFile = File(dir, "state.json")
    private val historyFile = File(dir, "history.jsonl")
    private val mutex = Mutex()
    private val compacting = AtomicBoolean(false)

    private var loaded = false
    private var summary = ""
    private val facts = mutableListOf<Fact>()
    private val window = mutableListOf<Turn>()

    companion object {
        private const val MAX_WINDOW = 24
        private const val KEEP_WINDOW = 10
        private const val RECENT_FOR_PROMPT = 8
        private const val MAX_FACTS = 300
    }

    private fun ensureLoaded() {
        if (loaded) return
        loaded = true
        try {
            if (stateFile.exists()) {
                val o = JSONObject(stateFile.readText())
                summary = o.optString("summary", "")
                o.optJSONArray("facts")?.let { a ->
                    for (i in 0 until a.length()) a.getJSONObject(i).let {
                        facts.add(Fact(it.optString("type", "fact"), it.optString("text"), it.optLong("ts")))
                    }
                }
                o.optJSONArray("window")?.let { a ->
                    for (i in 0 until a.length()) a.getJSONObject(i).let {
                        window.add(Turn(it.optString("role"), it.optString("text"), it.optLong("ts"), it.optString("emotion").ifBlank { null }))
                    }
                }
            }
        } catch (_: Exception) { /* arquivo corrompido: começa limpo */ }
    }

    private fun save() {
        val o = JSONObject()
        o.put("summary", summary)
        o.put("facts", JSONArray().also { a -> facts.forEach { a.put(JSONObject().put("type", it.type).put("text", it.text).put("ts", it.ts)) } })
        o.put("window", JSONArray().also { a -> window.forEach { a.put(turnJson(it)) } })
        val tmp = File(dir, "state.json.tmp")
        tmp.writeText(o.toString())
        if (!tmp.renameTo(stateFile)) { stateFile.writeText(o.toString()); tmp.delete() }
    }

    private fun turnJson(t: Turn) = JSONObject().put("role", t.role).put("text", t.text).put("ts", t.ts).also { if (t.emotion != null) it.put("emotion", t.emotion) }

    suspend fun isEmpty(): Boolean = mutex.withLock {
        withContext(Dispatchers.IO) { ensureLoaded(); summary.isEmpty() && facts.isEmpty() && window.isEmpty() && !historyFile.exists() }
    }

    suspend fun addExchange(user: Turn, model: Turn) = mutex.withLock {
        withContext(Dispatchers.IO) {
            ensureLoaded()
            window.add(user); window.add(model)
            historyFile.appendText(turnJson(user).toString() + "\n" + turnJson(model).toString() + "\n")
            save()
        }
    }

    /** memories: lista de (tipo, texto). Tipos: core, fact, preference, forget. */
    suspend fun applyMemories(memories: List<Pair<String, String>>) = mutex.withLock {
        withContext(Dispatchers.IO) {
            ensureLoaded()
            var changed = false
            for ((rawType, rawText) in memories) {
                val text = rawText.trim()
                if (text.length < 3) continue
                val type = rawType.trim().lowercase()
                if (type == "forget") {
                    val tk = tokens(text)
                    val n = norm(text)
                    val removed = facts.removeAll { f ->
                        val fn = norm(f.text)
                        fn.contains(n) || n.contains(fn) || (tk.isNotEmpty() && tokens(f.text).count { it in tk } >= minOf(2, tk.size))
                    }
                    if (removed) changed = true
                    continue
                }
                val t = if (type in setOf("core", "fact", "preference")) type else "fact"
                val n = norm(text.take(200))
                facts.removeAll { val fn = norm(it.text); fn == n || fn.contains(n) || n.contains(fn) }
                facts.add(Fact(t, text.take(200)))
                changed = true
            }
            while (facts.size > MAX_FACTS) {
                val idx = facts.indexOfFirst { it.type != "core" }
                facts.removeAt(if (idx >= 0) idx else 0)
            }
            if (changed) save()
        }
    }

    suspend fun contextFor(userText: String): PromptContext = mutex.withLock {
        withContext(Dispatchers.IO) {
            ensureLoaded()
            val lastUser = window.lastOrNull { it.role == "user" }?.text.orEmpty()
            val q = tokens(userText) + tokens(lastUser)
            val core = facts.filter { it.type == "core" }.takeLast(12)
            val prefs = facts.filter { it.type == "preference" }.takeLast(8)
            val others = facts.filter { it.type == "fact" }
            val scored = others.map { it to tokens(it.text).count { t -> t in q } }
                .filter { it.second > 0 }.sortedByDescending { it.second }.take(6).map { it.first }
            val rel = (scored + others.takeLast(3)).distinct()

            val sb = StringBuilder()
            if (core.isNotEmpty()) sb.append("## O que você sabe sobre o usuário\n").append(core.joinToString("\n") { "- ${it.text}" }).append("\n\n")
            if (prefs.isNotEmpty()) sb.append("## Preferências do usuário\n").append(prefs.joinToString("\n") { "- ${it.text}" }).append("\n\n")
            if (rel.isNotEmpty()) sb.append("## Lembranças possivelmente relevantes\n").append(rel.joinToString("\n") { "- ${it.text}" }).append("\n\n")
            if (summary.isNotBlank()) sb.append("## Resumo das conversas anteriores\n").append(summary).append("\n")

            var recent = window.takeLast(RECENT_FOR_PROMPT)
            while (recent.isNotEmpty() && recent.first().role != "user") recent = recent.drop(1)
            PromptContext(sb.toString().trim(), recent)
        }
    }

    /** Resume turnos antigos quando a janela cresce demais (economiza tokens). */
    suspend fun compactIfNeeded(summarizer: suspend (String, List<Turn>) -> String) {
        if (!compacting.compareAndSet(false, true)) return
        try {
            val snap = mutex.withLock {
                withContext(Dispatchers.IO) { ensureLoaded() }
                if (window.size <= MAX_WINDOW) null
                else Triple(window.size - KEEP_WINDOW, window.take(window.size - KEEP_WINDOW).toList(), summary)
            } ?: return
            val n = snap.first
            val toSum = snap.second
            val prev = snap.third
            val s = summarizer(prev, toSum)
            if (s.isBlank()) return
            mutex.withLock {
                withContext(Dispatchers.IO) {
                    summary = s.trim()
                    repeat(minOf(n, window.size)) { window.removeAt(0) }
                    save()
                }
            }
        } finally {
            compacting.set(false)
        }
    }

    suspend fun clearAll() = mutex.withLock {
        withContext(Dispatchers.IO) {
            loaded = true
            summary = ""; facts.clear(); window.clear()
            stateFile.delete(); historyFile.delete()
        }
    }

    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").trim()

    private fun tokens(s: String): Set<String> =
        norm(s).split(Regex("[^a-z0-9]+")).filter { it.length >= 4 }.map { it.take(5) }.toSet()
}
