package com.nexo.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexo.app.face.FaceView
import com.nexo.app.face.VoiceState

private val Blue = Color(0xFF2E9BFF)

class MainActivity : ComponentActivity() {
    private val vm: NexoViewModel by viewModels()

    private val micLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        vm.onMicPermission(granted)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContent { NexoApp(vm) }
    }

    override fun onStart() {
        super.onStart()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            vm.onMicPermission(true)
        } else {
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    override fun onStop() {
        vm.onBackground()
        super.onStop()
    }
}

@Composable
fun NexoApp(vm: NexoViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val view = LocalView.current
    SideEffect { view.keepScreenOn = ui.voice != VoiceState.IDLE }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(onTap = { vm.onTap() }, onLongPress = { vm.openSettings() })
            }
    ) {
        FaceView(vm.face)
        ui.notice?.let {
            BasicText(
                it,
                modifier = Modifier.align(Alignment.BottomCenter).padding(24.dp),
                style = TextStyle(color = Color(0x88FFFFFF), fontSize = 13.sp, textAlign = TextAlign.Center)
            )
        }
        if (ui.showSettings) SettingsOverlay(vm, ui.hasKey)
    }
}

@Composable
private fun SettingsOverlay(vm: NexoViewModel, hasKey: Boolean) {
    var key by remember { mutableStateOf("") }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xEE05080F))
            .pointerInput(Unit) { detectTapGestures { } }
            .imePadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.fillMaxWidth().padding(28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            BasicText("Chave da API Gemini", style = TextStyle(color = Blue, fontSize = 18.sp))
            BasicText(
                if (hasKey) "Já existe uma chave configurada. Cole outra para substituir." else "Cole sua chave do Google AI Studio.",
                style = TextStyle(color = Color(0xAAFFFFFF), fontSize = 13.sp, textAlign = TextAlign.Center)
            )
            BasicTextField(
                value = key,
                onValueChange = { key = it },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                cursorBrush = SolidColor(Blue),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF111B2B))
                    .padding(16.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Btn("Salvar") { if (key.isNotBlank()) { vm.saveKey(key); key = ""; vm.closeSettings() } }
                Btn("Apagar memória") { vm.clearMemory() }
                Btn("Fechar") { vm.closeSettings() }
            }
            BasicText(
                "Toque na tela: interrompe / escuta. Segure: abre esta tela.",
                style = TextStyle(color = Color(0x66FFFFFF), fontSize = 12.sp, textAlign = TextAlign.Center)
            )
        }
    }
}

@Composable
private fun Btn(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF16304F))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) { BasicText(label, style = TextStyle(color = Color.White, fontSize = 14.sp)) }
}
