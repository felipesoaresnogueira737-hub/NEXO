package com.nexo.app.face

enum class VoiceState { IDLE, LISTENING, THINKING, SPEAKING }

enum class Emotion(val id: String) {
    HAPPY("happy"), SAD("sad"), ANGRY("angry"), SURPRISED("surprised"), CURIOUS("curious"),
    THINKING("thinking"), CONFUSED("confused"), SLEEPY("sleepy"), EXCITED("excited"), NEUTRAL("neutral");

    companion object {
        fun from(id: String?): Emotion {
            val key = id?.trim()?.lowercase()
            return entries.firstOrNull { it.id == key } ?: NEUTRAL
        }
    }
}

/** Parâmetros que descrevem o rosto. Tudo é interpolado e animado por código. */
data class FaceParams(
    val eyeW: Float = 1f,        // escala da largura do olho
    val eyeH: Float = 1f,        // escala da altura do olho
    val tilt: Float = 0f,        // + = irritado (cantos internos baixos), - = triste
    val drop: Float = 0f,        // pálpebra superior caindo (sono)
    val happyCut: Float = 0f,    // pálpebra inferior subindo (olho feliz "^")
    val eyeY: Float = 0f,        // deslocamento vertical dos olhos
    val asym: Float = 0f,        // assimetria entre os olhos (curioso/confuso)
    val mouthW: Float = 1f,
    val smile: Float = 0.12f,    // + sorriso, - boca triste
    val open: Float = 0f,        // abertura da boca
    val mouthY: Float = 0f,
    val mouthTilt: Float = 0f,   // boca torta
    val lookX: Float = 0f,       // viés do olhar
    val lookY: Float = 0f
) {
    fun toArray() = floatArrayOf(
        eyeW, eyeH, tilt, drop, happyCut, eyeY, asym, mouthW, smile, open, mouthY, mouthTilt, lookX, lookY
    )

    fun lerp(o: FaceParams, t: Float): FaceParams {
        val a = toArray(); val b = o.toArray()
        return fromArray(FloatArray(a.size) { a[it] + (b[it] - a[it]) * t })
    }

    companion object {
        const val SIZE = 14
        const val I_OPEN = 9
        const val I_LOOK_X = 12
        const val I_LOOK_Y = 13
        fun fromArray(a: FloatArray) = FaceParams(
            a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12], a[13]
        )
    }
}

fun presetFor(e: Emotion): FaceParams = when (e) {
    Emotion.NEUTRAL -> FaceParams()
    Emotion.HAPPY -> FaceParams(eyeH = 0.95f, happyCut = 0.85f, eyeY = -0.03f, mouthW = 1.15f, smile = 0.85f, open = 0.12f)
    Emotion.SAD -> FaceParams(eyeH = 0.9f, tilt = -0.75f, drop = 0.12f, eyeY = 0.08f, mouthW = 0.8f, smile = -0.8f, mouthY = 0.1f, lookY = 0.5f)
    Emotion.ANGRY -> FaceParams(eyeH = 0.82f, tilt = 0.85f, drop = 0.05f, mouthW = 0.95f, smile = -0.55f)
    Emotion.SURPRISED -> FaceParams(eyeW = 1.0f, eyeH = 1.35f, eyeY = -0.05f, mouthW = 0.45f, smile = 0f, open = 1f, mouthY = 0.05f)
    Emotion.CURIOUS -> FaceParams(eyeH = 1.12f, asym = 0.45f, mouthW = 0.7f, smile = 0.25f, mouthTilt = 0.35f, lookX = 0.2f, lookY = -0.2f)
    Emotion.THINKING -> FaceParams(eyeH = 0.8f, drop = 0.1f, mouthW = 0.55f, smile = -0.05f, mouthTilt = -0.3f, lookX = 0.55f, lookY = -0.65f)
    Emotion.CONFUSED -> FaceParams(asym = 0.6f, tilt = -0.35f, mouthW = 0.8f, smile = -0.25f, mouthTilt = 0.5f, lookX = -0.2f)
    Emotion.SLEEPY -> FaceParams(eyeH = 0.85f, drop = 0.6f, eyeY = 0.05f, mouthW = 0.55f, smile = 0f, open = 0.18f, lookY = 0.3f)
    Emotion.EXCITED -> FaceParams(eyeW = 1.05f, eyeH = 1.15f, happyCut = 0.45f, mouthW = 1.2f, smile = 0.95f, open = 0.55f)
}
