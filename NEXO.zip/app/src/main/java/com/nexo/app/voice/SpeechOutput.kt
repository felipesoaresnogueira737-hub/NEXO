package com.nexo.app.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Síntese de voz (TextToSpeech). Cada palavra falada dispara onWord() para animar a boca. */
class SpeechOutput(context: Context, private val cb: Callback) : TextToSpeech.OnInitListener {
    interface Callback {
        fun onSpeakStart()
        fun onWord()
        fun onSpeakEnd(interrupted: Boolean)
        fun onVoiceProblem(message: String)
    }

    private class Pending(val text: String, val rate: Float, val pitch: Float)

    private val main = Handler(Looper.getMainLooper())
    private val tts = TextToSpeech(context.applicationContext, this)
    private var ready = false
    private var failed = false
    private var pending: Pending? = null
    private var currentId = 0
    private var activeId = -1

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            failed = true
            main.post { cb.onVoiceProblem("Síntese de voz indisponível neste aparelho"); pending?.let { pending = null; cb.onSpeakEnd(false) } }
            return
        }
        val r = tts.setLanguage(Locale("pt", "BR"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            main.post { cb.onVoiceProblem("Voz em português não instalada (use outra voz nas configurações do TTS)") }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            private fun id(u: String?) = u?.toIntOrNull() ?: -1
            override fun onStart(utteranceId: String?) { if (id(utteranceId) == activeId) main.post { if (id(utteranceId) == activeId) cb.onSpeakStart() } }
            override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                if (id(utteranceId) == activeId) main.post { if (id(utteranceId) == activeId) cb.onWord() }
            }
            override fun onDone(utteranceId: String?) { finish(id(utteranceId), false) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { finish(id(utteranceId), true) }
            override fun onError(utteranceId: String?, errorCode: Int) { finish(id(utteranceId), true) }
            override fun onStop(utteranceId: String?, interrupted: Boolean) { /* interrupções são tratadas em stop() */ }
            private fun finish(i: Int, err: Boolean) {
                main.post {
                    if (i == activeId) {
                        activeId = -1
                        if (err) cb.onVoiceProblem("Erro ao falar")
                        cb.onSpeakEnd(false)
                    }
                }
            }
        })
        ready = true
        pending?.let { pending = null; doSpeak(it) }
    }

    fun speak(text: String, rate: Float, pitch: Float) {
        val clean = clean(text)
        if (clean.isBlank()) { main.post { cb.onSpeakEnd(false) }; return }
        val p = Pending(clean.take(3500), rate, pitch)
        when {
            failed -> main.post { cb.onSpeakEnd(false) }
            !ready -> pending = p
            else -> doSpeak(p)
        }
    }

    private fun doSpeak(p: Pending) {
        currentId++
        activeId = currentId
        tts.setSpeechRate(p.rate.coerceIn(0.5f, 2f))
        tts.setPitch(p.pitch.coerceIn(0.5f, 2f))
        val res = tts.speak(p.text, TextToSpeech.QUEUE_FLUSH, null, activeId.toString())
        if (res != TextToSpeech.SUCCESS) { activeId = -1; main.post { cb.onVoiceProblem("Falha ao iniciar a voz"); cb.onSpeakEnd(false) } }
    }

    /** Interrompe a fala em andamento sem disparar onSpeakEnd. */
    fun stop() {
        pending = null
        activeId = -1
        if (ready) try { tts.stop() } catch (_: Exception) {}
    }

    fun shutdown() { stop(); try { tts.shutdown() } catch (_: Exception) {} }

    companion object {
        /** Deixa o texto agradável para a voz: sem emojis/markdown, gírias de chat expandidas. */
        fun clean(s: String): String {
            var t = s
            t = t.replace(Regex("(?i)\\bk{3,}\\b"), "hahaha")
            t = t.replace(Regex("(?i)\\b(rs){2,}\\b"), "hahaha")
            t = t.replace(Regex("(?i)\\bmn\\b"), "mano")
            t = t.replace(Regex("(?i)\\bvc\\b"), "você")
            t = t.replace(Regex("(?i)\\btbm\\b"), "também")
            t = t.replace(Regex("(?i)\\bpq\\b"), "porque")
            t = t.replace(Regex("[*_#`~>|]"), " ")
            t = t.replace(Regex("[\\p{So}\\p{Cn}\\x{FE0F}\\x{200D}]"), "")
            return t.replace(Regex("\\s+"), " ").trim()
        }
    }
}
