package com.nexo.app.face

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

private val EyeColor = Color(0xFF2E9BFF)
private val EyeHighlight = Color(0xFFBFE4FF)
private val MouthFill = Color(0xFF07254D)

@Composable
fun FaceView(face: FaceController, modifier: Modifier = Modifier) {
    var frame by remember { mutableLongStateOf(0L) }
    LaunchedEffect(face) {
        var t0 = 0L
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (t0 == 0L) { t0 = now; last = now }
                val dt = ((now - last) / 1_000_000_000f).coerceAtMost(0.1f)
                // em repouso, 30 fps bastam (economiza bateria)
                val skip = face.state == VoiceState.IDLE && dt < 0.033f
                if (!skip) {
                    last = now
                    face.update(dt, (now - t0) / 1_000_000_000f)
                    frame = now
                }
            }
        }
    }
    Canvas(modifier.fillMaxSize()) {
        val f = frame
        if (f >= 0L) drawFace(face)
    }
}

private fun DrawScope.glowPath(path: Path, u: Float, fill: Boolean) {
    val k = u / 1080f
    for ((w, a) in listOf(46f to 0.05f, 28f to 0.08f, 14f to 0.14f)) {
        drawPath(path, EyeColor.copy(alpha = a), style = Stroke(width = w * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
    if (fill) drawPath(path, EyeColor)
}

private fun DrawScope.drawFace(f: FaceController) {
    val w = size.width
    val h = size.height
    val u = min(w, h * 0.62f)
    val cx = w / 2f
    val cy = h / 2f - h * 0.03f + f.breath * u * 0.004f
    val p = f.params()

    val eyeBaseW = 0.17f * u
    val eyeBaseH = 0.25f * u
    val sep = 0.2f * u
    val eyeCy = cy - 0.08f * u + p.eyeY * 0.1f * u + f.gazeY * 0.04f * u
    val gx = f.gazeX * 0.05f * u

    drawEye(cx - sep + gx, eyeCy, -1, eyeBaseW * p.eyeW, eyeBaseH * p.eyeH * (1f + p.asym * 0.28f), f.blinkL, p, u)
    drawEye(cx + sep + gx, eyeCy, 1, eyeBaseW * p.eyeW, eyeBaseH * p.eyeH * (1f - p.asym * 0.28f), f.blinkR, p, u)

    drawMouth(cx + f.gazeX * 0.012f * u, cy + 0.3f * u + p.mouthY * 0.1f * u, p, u)
    drawIndicator(f, cx, min(h - 0.08f * u, cy + 0.62f * u), u)
}

private fun DrawScope.drawEye(cx: Float, cy: Float, side: Int, w: Float, hFull: Float, blink: Float, p: FaceParams, u: Float) {
    val h = (hFull * blink).coerceAtLeast(0.012f * u)
    val left = cx - w / 2f
    val top = cy - h / 2f
    val r = min(w, h) * 0.45f
    var shape = Path().apply { addRoundRect(RoundRect(left, top, left + w, top + h, CornerRadius(r, r))) }

    // pálpebra superior: inclinação (irritado/triste) + queda (sono)
    if (abs(p.tilt) > 0.01f || p.drop > 0.01f) {
        val k = h * 0.55f
        val base = top + p.drop * h * 0.9f
        val yInner = base + p.tilt * k
        val yOuter = base - p.tilt * k
        val xi = if (side < 0) left + w else left
        val xo = if (side < 0) left else left + w
        val slope = (yInner - yOuter) / (xi - xo)
        val ext = w * 0.15f
        val xa = left - ext
        val xb = left + w + ext
        val cut = Path().apply {
            moveTo(xa, yOuter + slope * (xa - xo))
            lineTo(xb, yOuter + slope * (xb - xo))
            lineTo(xb, top - h)
            lineTo(xa, top - h)
            close()
        }
        shape = Path.combine(PathOperation.Difference, shape, cut)
    }
    // pálpebra inferior subindo: olho feliz "^"
    if (p.happyCut > 0.02f) {
        val by = top + h + h * 0.12f
        val rx = w * 0.7f
        val ry = h * 0.95f * p.happyCut
        val oval = Path().apply { addOval(Rect(cx - rx, by - ry, cx + rx, by + ry)) }
        shape = Path.combine(PathOperation.Difference, shape, oval)
    }

    glowPath(shape, u, fill = true)
    if (blink > 0.5f) {
        clipPath(shape) {
            drawCircle(EyeHighlight.copy(alpha = 0.5f), radius = w * 0.09f, center = Offset(left + w * 0.3f, top + h * 0.26f))
        }
    }
}

private fun DrawScope.drawMouth(cx: Float, cy: Float, p: FaceParams, u: Float) {
    val h0 = 0.085f * u
    val hw = h0 * p.mouthW
    val tiltY = p.mouthTilt * hw * 0.5f
    val x0 = cx - hw
    val x1 = cx + hw
    val y0 = cy - tiltY
    val y1 = cy + tiltY
    val smileOff = p.smile * hw * 0.9f
    val upperCtrlY = cy + smileOff - p.open * h0 * 0.4f
    val lowerCtrlY = cy + smileOff + p.open * h0 * 1.6f
    val line = Stroke(width = 0.014f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)

    val path = Path().apply {
        moveTo(x0, y0)
        quadraticTo(cx, upperCtrlY, x1, y1)
        if (p.open > 0.04f) {
            quadraticTo(cx, lowerCtrlY, x0, y0)
            close()
        }
    }
    if (p.open > 0.04f) drawPath(path, MouthFill)
    val k = u / 1080f
    for ((w, a) in listOf(40f to 0.05f, 24f to 0.08f, 12f to 0.14f)) {
        drawPath(path, EyeColor.copy(alpha = a), style = Stroke(width = w * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
    drawPath(path, EyeColor, style = line)
}

private fun DrawScope.drawIndicator(f: FaceController, cx: Float, y: Float, u: Float) {
    val t = f.clock
    when (f.state) {
        VoiceState.LISTENING -> {
            val amp = 0.25f + 0.75f * f.rms
            for (i in 0 until 5) {
                val ph = sin(t * 6f + i * 1.1f) * 0.5f + 0.5f
                val bh = u * 0.012f + u * 0.05f * amp * ph * (1f - abs(i - 2) * 0.18f)
                val bw = u * 0.012f
                val x = cx + (i - 2) * u * 0.035f
                drawRoundRect(EyeColor.copy(alpha = 0.85f), Offset(x - bw / 2f, y - bh / 2f), Size(bw, bh), CornerRadius(bw / 2f))
            }
        }
        VoiceState.THINKING -> {
            for (i in 0 until 3) {
                val s = sin(t * 5f - i * 0.9f) * 0.5f + 0.5f
                drawCircle(EyeColor.copy(alpha = 0.4f + 0.6f * s), u * 0.009f * (0.7f + 0.8f * s), Offset(cx + (i - 1) * u * 0.04f, y))
            }
        }
        VoiceState.SPEAKING -> {
            val lw = u * 0.12f * (0.5f + 0.5f * f.pulse)
            drawLine(EyeColor.copy(alpha = 0.5f), Offset(cx - lw / 2f, y), Offset(cx + lw / 2f, y), strokeWidth = u * 0.006f, cap = StrokeCap.Round)
        }
        VoiceState.IDLE -> {
            val a = 0.15f + 0.1f * (sin(t * 1.7f) * 0.5f + 0.5f)
            drawCircle(EyeColor.copy(alpha = a), u * 0.006f, Offset(cx, y))
        }
    }
}
