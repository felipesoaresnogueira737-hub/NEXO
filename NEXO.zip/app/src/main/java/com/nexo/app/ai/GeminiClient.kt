package com.nexo.app.ai

import com.nexo.app.face.Emotion
import com.nexo.app.memory.Turn
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class GeminiException(val kind: Kind, message: String?, val http: Int = 0) : Exception(message) {
    enum class Kind { NO_KEY, BAD_KEY, NETWORK, RATE, NOT_FOUND, BLOCKED, BAD_REPLY, OTHER }
}

data class GeminiReply(
    val response: String,
    val emotion: Emotion,
    val intensity: Float,
    val gaze: String,
    val behavior: String,
    val memories: List<Pair<String, String>>
)

/**
 * Cliente REST oficial do Gemini (generativelanguage.googleapis.com, endpoint generateContent).
 * Usa saída estruturada (responseSchema) e faz fallback automático entre modelos/parâmetros
 * de raciocínio, já que o Google troca nomes de modelos e o formato de "thinking" entre gerações.
 */
class GeminiClient(
    private val keyProvider: () -> String,
    private val preferredModel: () -> String,
    private val onModelWorked: (String) -> Unit
) {
    companion object {
        private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
        private val FALLBACK_MODELS = listOf("gemini-flash-latest", "gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash")
        private val EMOTIONS = Emotion.entries.map { it.id }
        private val GAZES = listOf("center", "up", "down", "left", "right", "up_left", "up_right", "away")
        private val BEHAVIORS = listOf("none", "wink", "squint", "wide_eyes", "look_around", "giggle")
    }

    private fun enumStr(values: List<String>) =
        JSONObject().put("type", "STRING").put("format", "enum").put("enum", JSONArray(values))

    private val schema: JSONObject = JSONObject()
        .put("type", "OBJECT")
        .put("properties", JSONObject()
            .put("response", JSONObject().put("type", "STRING"))
            .put("emotion", enumStr(EMOTIONS))
            .put("intensity", JSONObject().put("type", "NUMBER"))
            .put("gaze", enumStr(GAZES))
            .put("behavior", enumStr(BEHAVIORS))
            .put("memory", JSONObject().put("type", "ARRAY").put("items", JSONObject()
                .put("type", "OBJECT")
                .put("properties", JSONObject()
                    .put("type", enumStr(listOf("core", "fact", "preference", "forget")))
                    .put("text", JSONObject().put("type", "STRING")))
                .put("required", JSONArray(listOf("type", "text"))))))
        .put("required", JSONArray(listOf("response", "emotion", "intensity", "gaze", "behavior", "memory")))
        .put("propertyOrdering", JSONArray(listOf("response", "emotion", "intensity", "gaze", "behavior", "memory")))

    suspend fun chat(system: String, history: List<Turn>, userText: String): GeminiReply {
        val contents = JSONArray()
        history.forEach { contents.put(content(if (it.role == "user") "user" else "model", it.text)) }
        contents.put(content("user", userText))
        val raw = generate(system, contents, schema, 1.0, 2048)
        return parseReply(raw)
    }

    suspend fun summarize(previous: String, turns: List<Turn>): String {
        val sb = StringBuilder()
        if (previous.isNotBlank()) sb.append("Resumo atual:\n").append(previous).append("\n\n")
        sb.append("Novas mensagens:\n")
        turns.forEach { sb.append(if (it.role == "user") "Usuário: " else "NEXO: ").append(it.text).append('\n') }
        sb.append("\nAtualize o resumo em português, em até 120 palavras, na terceira pessoa (\"O usuário...\"), mantendo só o que ajuda a dar continuidade às conversas futuras (assuntos, combinados, humor, pendências). Responda apenas com o resumo.")
        val contents = JSONArray().put(content("user", sb.toString()))
        return generate("Você resume conversas de forma fiel e concisa.", contents, null, 0.3, 600).trim()
    }

    private fun content(role: String, text: String) =
        JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))

    private fun body(system: String, contents: JSONArray, schema: JSONObject?, temp: Double, maxTokens: Int, thinking: JSONObject?): JSONObject {
        val gc = JSONObject().put("temperature", temp).put("maxOutputTokens", maxTokens)
        if (schema != null) gc.put("responseMimeType", "application/json").put("responseSchema", schema)
        if (thinking != null) gc.put("thinkingConfig", thinking)
        return JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", gc)
    }

    private suspend fun generate(system: String, contents: JSONArray, schema: JSONObject?, temp: Double, maxTokens: Int): String {
        val key = keyProvider()
        if (key.isBlank()) throw GeminiException(GeminiException.Kind.NO_KEY, "Sem chave da API")
        val models = (listOf(preferredModel()) + FALLBACK_MODELS).filter { it.isNotBlank() }.distinct()
        var lastNotFound: GeminiException? = null
        for (model in models) {
            // tentativas de configuração de raciocínio: variam entre gerações de modelo
            val attempts: List<JSONObject?> = when {
                "2.5" in model -> listOf(JSONObject().put("thinkingBudget", 0), null)
                else -> listOf(JSONObject().put("thinkingLevel", "LOW"), JSONObject().put("thinkingBudget", 0), null)
            }
            for (th in attempts) {
                try {
                    val text = post(model, key, body(system, contents, schema, temp, maxTokens, th))
                    onModelWorked(model)
                    return text
                } catch (e: GeminiException) {
                    val msg = e.message.orEmpty().lowercase()
                    when {
                        e.kind == GeminiException.Kind.NOT_FOUND -> { lastNotFound = e; break }
                        e.http == 400 && ("thinking" in msg) -> continue
                        else -> throw e
                    }
                }
            }
        }
        throw lastNotFound ?: GeminiException(GeminiException.Kind.OTHER, "Nenhum modelo disponível")
    }

    private suspend fun post(model: String, key: String, payload: JSONObject): String = withContext(Dispatchers.IO) {
        val conn = (URL("$BASE$model:generateContent").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10_000
            readTimeout = 40_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-goog-api-key", key)
        }
        coroutineScope {
            // se a corrida for cancelada (usuário interrompeu), derruba a conexão bloqueada
            val watcher = launch { try { awaitCancellation() } finally { conn.disconnect() } }
            try {
                conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code !in 200..299) throw httpError(code, text)
                extractText(text)
            } catch (e: CancellationException) {
                throw e
            } catch (e: GeminiException) {
                throw e
            } catch (e: IOException) {
                throw GeminiException(GeminiException.Kind.NETWORK, e.message)
            } finally {
                watcher.cancel()
            }
        }
    }

    private fun httpError(code: Int, body: String): GeminiException {
        val msg = try { JSONObject(body).optJSONObject("error")?.optString("message").orEmpty() } catch (_: Exception) { body.take(200) }
        val low = msg.lowercase()
        val kind = when {
            code == 404 -> GeminiException.Kind.NOT_FOUND
            code == 429 -> GeminiException.Kind.RATE
            code == 401 || code == 403 || (code == 400 && ("api key" in low || "api_key" in low)) -> GeminiException.Kind.BAD_KEY
            else -> GeminiException.Kind.OTHER
        }
        return GeminiException(kind, "HTTP $code: $msg", code)
    }

    private fun extractText(raw: String): String {
        val root = try { JSONObject(raw) } catch (e: Exception) { throw GeminiException(GeminiException.Kind.BAD_REPLY, "Resposta inválida") }
        val block = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
        if (block.isNotBlank()) throw GeminiException(GeminiException.Kind.BLOCKED, "Bloqueado: $block")
        val cand = root.optJSONArray("candidates")?.optJSONObject(0)
            ?: throw GeminiException(GeminiException.Kind.BLOCKED, "Sem candidatos")
        val parts = cand.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (!p.optBoolean("thought", false)) sb.append(p.optString("text", ""))
        }
        if (sb.isBlank()) throw GeminiException(GeminiException.Kind.BLOCKED, "Resposta vazia (${cand.optString("finishReason")})")
        return sb.toString()
    }

    private fun parseReply(raw: String): GeminiReply {
        var t = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val o = try {
            JSONObject(t)
        } catch (e: Exception) {
            val a = t.indexOf('{'); val b = t.lastIndexOf('}')
            try { JSONObject(t.substring(a, b + 1)) } catch (e2: Exception) {
                // modelo devolveu texto puro: usa como fala, emoção neutra
                return GeminiReply(t, Emotion.NEUTRAL, 0.3f, "center", "none", emptyList())
            }
        }
        val mem = mutableListOf<Pair<String, String>>()
        o.optJSONArray("memory")?.let { a ->
            for (i in 0 until a.length()) a.optJSONObject(i)?.let { mem.add(it.optString("type", "fact") to it.optString("text", "")) }
        }
        val response = o.optString("response", "").trim()
        if (response.isEmpty()) throw GeminiException(GeminiException.Kind.BAD_REPLY, "Resposta sem texto")
        return GeminiReply(
            response,
            Emotion.from(o.optString("emotion")),
            o.optDouble("intensity", 0.6).toFloat().coerceIn(0f, 1f),
            o.optString("gaze", "center"),
            o.optString("behavior", "none"),
            mem
        )
    }
}
