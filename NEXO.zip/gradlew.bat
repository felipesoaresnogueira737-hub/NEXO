@echo off
set J=%~dp0gradle\wrapper\gradle-wrapper.jar
if exist "%J%" ( java -classpath "%J%" org.gradle.wrapper.GradleWrapperMain %* & exit /b %errorlevel% )
gradle %*
